﻿namespace Day4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Q1
            ////Q1
            //int[] Num = new int[3] { 1, 2, 3 };
            //int[] Num2 = new int[] { 1, 2, 3 };
            //int[] Num3 = { 1, 2, 3 }; //syntax sugar

            //Console.WriteLine("Array1:");
            //for (int i = 0; i < array1.Length; i++)
            //{
            //    array1[i] = i + 1; 
            //    Console.WriteLine($"Element {i}: {array1[i]}");
            //}

            //Console.WriteLine("\nArray2:");
            //for (int i = 0; i < array2.Length; i++)
            //{
            //    Console.WriteLine($"Element {i}: {array2[i]}");
            //}

            //Console.WriteLine("\nArray3:");
            //foreach (int value in array3)
            //{
            //    Console.WriteLine($"Element: {value}");
            //}

            //try
            //{
            //    Console.WriteLine("\nAttempting to access an out-of-range index in Array1:");
            //    Console.WriteLine(array1[10]); 
            //}
            //catch (IndexOutOfRangeException ex)
            //{
            //    Console.WriteLine($"Exception caught: {ex.Message}");
            //}
            //// The default value assigned to array elements in C# depends on the type of the array:
            //*Numeric types: 0
            //*Boolean: false
            //*Reference types: null
            #endregion

            #region Q2
            ////Q2
            //int[] arr1 = { 1, 2, 3, 4, 5 };
            //int[] arr2 = new int[5];

            //arr2 = arr1;
            //Console.WriteLine("Shallow Copy:");
            //Console.WriteLine("arr1: " + string.Join(", ", arr1));
            //Console.WriteLine("arr2: " + string.Join(", ", arr2));

            //arr1[0] = 99;
            //Console.WriteLine("\nAfter modifying arr1[0]:");
            //Console.WriteLine("arr1: " + string.Join(", ", arr1));
            //Console.WriteLine("arr2: " + string.Join(", ", arr2));

            //int[] arr3 = (int[])arr1.Clone();
            //Console.WriteLine("\nDeep Copy (using Clone):");
            //Console.WriteLine("arr1: " + string.Join(", ", arr1));
            //Console.WriteLine("arr3: " + string.Join(", ", arr3));

            //arr1[1] = 88;
            //Console.WriteLine("\nAfter modifying arr1[1]:");
            //Console.WriteLine("arr1: " + string.Join(", ", arr1));
            //Console.WriteLine("arr3: " + string.Join(", ", arr3));

            ////*Array.Clone():

            ////Creates a shallow copy of the array.
            ////For simple arrays(like int[]), it behaves like a deep copy because each element is copied
            ////directly. However, for arrays containing references(e.g., arrays of objects), the references
            ////are copied, not the objects themselves.


            ////*Array.Copy():

            ////Copies elements from one array to another.You can specify the range of elements to copy.
            ////By default, Array.Copy() also performs a shallow copy, meaning it copies the values or references, but not the actual objects(in the case of arrays of objects).
            #endregion

            #region Q3
            ////Q3
            //int[,] grades = new int[3, 3];
            //Console.WriteLine("Enter the grades for 3 students (3 subjects each):");
            //for (int student = 0; student < grades.GetLength(0); student++) 
            //{
            //    for (int subject = 0; subject < grades.GetLength(1); subject++) 
            //    {
            //        Console.Write($"Student {student + 1}, Subject {subject + 1}: ");
            //        grades[student, subject] = int.Parse(Console.ReadLine());
            //    }
            //}

            //Console.WriteLine("\nGrades for each student:");
            //for (int student = 0; student < grades.GetLength(0); student++)
            //{
            //    Console.Write($"Student {student + 1}: ");
            //    for (int subject = 0; subject < grades.GetLength(1); subject++)
            //    {
            //        Console.Write(grades[student, subject] + " ");
            //    }
            //    Console.WriteLine();
            //}

            ////*GetLength(dimension)
            ////Used to get the size of a specific dimension in a multi-dimensional array.
            ////Syntax: array.GetLength(dimension)
            ////dimension starts from 0(0 for rows, 1 for columns in a 2D array).
            ////Example:

            //int[,] arr = new int[3, 4];
            //Console.WriteLine(arr.GetLength(0)); // Output: 3 (rows)
            //Console.WriteLine(arr.GetLength(1)); // Output: 4 (columns)

            ////*Length
            ////Returns the total number of elements in the array(all dimensions combined).
            ////Example:

            //int[,] arr = new int[3, 4];
            //Console.WriteLine(arr.Length); // Output: 12 (3 rows × 4 columns)

            #endregion

            #region Q5
            //Q4
            //int[] numbers = { 5, 3, 8, 1, 4 };
            //// Display original array
            //Console.WriteLine("Original array: " + string.Join(", ", numbers));
            //// Sort:Sorts the array in ascending order
            //Array.Sort(numbers);
            //Console.WriteLine("After Sort: " + string.Join(", ", numbers));
            //// Reverse:Reverses the order of the elements in the array
            //Array.Reverse(numbers);
            //Console.WriteLine("After Reverse: " + string.Join(", ", numbers));
            //// IndexOf:Finds the index of a specific element
            //int index = Array.IndexOf(numbers, 8);
            //Console.WriteLine("Index of 8: " + index);
            //// Copy:Copies elements of one array to another
            //int[] copiedArray = new int[numbers.Length];
            //Array.Copy(numbers, copiedArray, numbers.Length);
            //Console.WriteLine("Copied array: " + string.Join(", ", copiedArray));
            //// Clear:Clears elements in the array (sets them to default values)
            //Array.Clear(numbers, 0, numbers.Length);
            //Console.WriteLine("After Clear: " + string.Join(", ", numbers));
            ////Array.Copy():
            ////Provides a general way to copy elements from one array to another.
            ////Does not perform runtime checks for type safety;
            ///copying arrays of incompatible types can result in an exception.
            ////May succeed or fail during runtime without providing strict guarantees.

            ////Array.ConstrainedCopy():
            ////Provides a more constrained and reliable copy operation.
            ////Performs runtime checks to ensure type safety before copying elements.
            ///If the operation cannot be completed safely, it will not copy any data and will throw an exception.
            ////Typically used in environments where reliability is critical.
            #endregion

            #region Q5
            ////Q5
            //int[] numbers = { 10, 20, 30, 40, 50 };
            //Console.WriteLine("Using for loop:");
            //for (int i = 0; i < numbers.Length; i++)
            //{
            //    Console.WriteLine(numbers[i]);
            //}
            //Console.WriteLine("\nUsing foreach loop:");
            //foreach (int number in numbers)
            //{
            //    Console.WriteLine(number);
            //}
            //Console.WriteLine("\nUsing while loop in reverse order:");
            //int index = numbers.Length - 1;
            //while (index >= 0)
            //{
            //    Console.WriteLine(numbers[index]);
            //    index--;
            //}

            ////Why is foreach Preferred for Read - Only Operations on Arrays ?
            ////Read - Only Behavior: The foreach loop is designed for iterating over a collection without modifying it.
            ///The iterator variable in foreach is read - only, which helps prevent accidental changes to array elements.
            ////Simplicity: foreach eliminates the need for managing indices manually.
            ///This reduces the chance of errors like index out-of - bounds or miscalculations.
            ////Clarity: foreach clearly communicates that the purpose of the loop is to access elements,
            ///not to modify them, making code easier to understand.
            #endregion

            #region Q6
            ////Q6
            //int number;
            //bool isValid;
            //do
            //{
            //    Console.Write("Enter a positive odd number: ");
            //    string input = Console.ReadLine();
            //    isValid = int.TryParse(input, out number) && number > 0 && number % 2 != 0;
            //    if (!isValid)
            //    {
            //        Console.WriteLine("Invalid input. Please enter a positive odd number.");
            //    }
            //} while (!isValid);

            //Console.WriteLine($"Thank you! You entered a valid number: {number}");

            ////Why is input validation important ?
            ////Preventing errors: Ensures that invalid inputs don’t cause the program to fail or behave unexpectedly.
            ////Enhancing security: Protects against harmful or malicious inputs that could exploit vulnerabilities.
            ////Ensuring data accuracy: Guarantees that only correct and usable data is processed.
            ////Improving user experience: Provides clear feedback to users, helping them input the correct data easily.
            ////Avoiding crashes: Makes the program more stable and prevents it from crashing due to bad inputs.

            #endregion

            #region Q7
            ////Q7
            //int[,] matrix = {
            //{ 1, 2, 3 },
            //{ 4, 5, 6 },
            //{ 7, 8, 9 }
            //};
            //Console.WriteLine("2D Array in Matrix Format:");
            //for (int i = 0; i < matrix.GetLength(0); i++) 
            //{
            //    for (int j = 0; j < matrix.GetLength(1); j++) 
            //    {
            //        Console.Write(matrix[i, j] + "\t"); 
            //    }
            //    Console.WriteLine();
            //}

            ////How can you improve the formatting of a 2D array's output?
            ////Use tabs(\t): To align columns neatly.
            ////Set a fixed width for elements: Use formatting like { 0,5}
            ////to make all elements take up the same space.
            ////Add labels: Add row and column labels to clarify the data.
            ////Use separators: Add | or - to make the output look like a table.
            ////Add spacing between rows: To make large arrays easier to read.
            ////This makes the data clearer and more organized for better readability.
            #endregion

            #region Q8
            ////Q8
            //int monthNumber;
            //bool flag = true;
            //do
            //{
            //    Console.Write("Enter month number: ");
            //    flag = int.TryParse(Console.ReadLine(), out monthNumber);
            //}
            //while (!flag);

            //if (monthNumber == 1)
            //{
            //    Console.WriteLine("January");
            //}
            //else if (monthNumber == 2)
            //{
            //    Console.WriteLine("February");
            //}
            //else if (monthNumber == 3)
            //{
            //    Console.WriteLine("March");
            //}
            //else if (monthNumber == 4)
            //{
            //    Console.WriteLine("April");
            //}
            //else if (monthNumber == 5)
            //{
            //    Console.WriteLine("May");
            //}
            //else if (monthNumber == 6)
            //{
            //    Console.WriteLine("June");
            //}
            //else if (monthNumber == 7)
            //{
            //    Console.WriteLine("July");
            //}
            //else if (monthNumber == 8)
            //{
            //    Console.WriteLine("August");
            //}
            //else if (monthNumber == 9)
            //{
            //    Console.WriteLine("September");
            //}
            //else if (monthNumber == 10)
            //{
            //    Console.WriteLine("October");
            //}
            //else if (monthNumber == 11)
            //{
            //    Console.WriteLine("November");
            //}
            //else if (monthNumber == 12)
            //{
            //    Console.WriteLine("December");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid month number");
            //}


            //switch (monthNumber)
            //{
            //    case 1:
            //        Console.WriteLine("January");
            //        break;
            //    case 2:
            //        Console.WriteLine("February");
            //        break;
            //    case 3:
            //        Console.WriteLine("March");
            //        break;
            //    case 4:
            //        Console.WriteLine("April");
            //        break;
            //    case 5:
            //        Console.WriteLine("May");
            //        break;
            //    case 6:
            //        Console.WriteLine("June");
            //        break;
            //    case 7:
            //        Console.WriteLine("July");
            //        break;
            //    case 8:
            //        Console.WriteLine("August");
            //        break;
            //    case 9:
            //        Console.WriteLine("September");
            //        break;
            //    case 10:
            //        Console.WriteLine("October");
            //        break;
            //    case 11:
            //        Console.WriteLine("November");
            //        break;
            //    case 12:
            //        Console.WriteLine("December");
            //        break;
            //    default:
            //        Console.WriteLine("Invalid month number");
            //        break;
            //}

            ////We prefer a switch statement over if-else when:
            ////1. You have multiple discrete values to compare
            ////2. You are comparing a single expression against multiple constant values
            ////3. You are dealing with Enums
            ////4. You want a more structured and easy-to-maintain solution
            #endregion

            #region Q9
            ////Q9
            //int[] arr = { 4, 2, 6, 8, 3, 7, 7, 1, 9, 5, 7 };

            ////Sort
            //Array.Sort(arr);
            //Console.Write("[");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    if (i != arr.Length - 1)
            //    {
            //        Console.Write($"{arr[i]}, ");
            //    }
            //    else
            //    {
            //        Console.Write(arr[i]);
            //    }
            //}
            //Console.WriteLine("]");

            ////IndexOf(array, element): Return the first index with value = element from array
            //Console.WriteLine(Array.IndexOf(arr, 7));
            ////LastIndexOf(array, element): Return the last index with value = element from array
            //Console.WriteLine(Array.LastIndexOf(arr, 7));

            ////Array.Sort() time complexity (depends on used algorithm to sort):
            ////1. With Primitive Types => use Dual-Pivot Quicksort, time complexity:
            ////  - Best and Average case: O(n logn)
            ////  - Worsc case: O(n^2)
            ////2. With Reference Types => use TimeSort, time complexity:
            ////  - Best case: O(n)
            ////  - Average and Worst case: O(n logn) 
            #endregion

            #region Q10
            ////Q10
            //int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //int sum = 0;

            ////for
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    sum += arr[i];
            //}
            //Console.WriteLine(sum);

            //sum = 0;

            ////foreach
            //foreach (int item in arr)
            //{
            //    sum += item;
            //}
            //Console.WriteLine(sum);

            ///*
            // * for is more efficient:
            // *      The for loop allows you to work directly with the index, and there is no need to create an enumerator or iterator,
            // *      which can add a small overhead in the foreach loop.
            //*/ 
            #endregion

            #region part2
            //Part Q2
            //int input = int.Parse(Console.ReadLine());
            //if (input > 7 || input < 0)
            //{
            //    Console.WriteLine("invalid input");

            //}
            //else
            //{
            //    DayOfWeek day = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), input.ToString());
            //    Console.WriteLine("The corresponding day is: " + day);
            //}

            ////if input not exist between 1:7 the output will be "invalid input".

            #endregion
        }
        #region part2 
        //static void CalculateAvrage(int[] numbers)
        //{



        //    int sum = 0;
        //    foreach (int number in numbers)

        //        sum += number;
        //    double average = sum / numbers.Length;
        //    Console.WriteLine($"Average = {average}");
        //}
        //enum DayOfWeek
        //{
        //    Monday = 1,
        //    Tuesday,
        //    Wednesday,
        //    Thursday,
        //    Friday,
        //    Saturday,
        //    Sunday
        //}
        #endregion
    }
}
